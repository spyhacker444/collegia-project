// MOCK DB - Add more students here
const studentDB = [
  { name: 'anupma jain', room: 'G3 room' },
  { name: 'sanjay bhan', room: 'S-28 room' },
  { name: 'priya sharma', room: 'B-15 room' }
];

function logout() {
  localStorage.removeItem('chatbotUser');
  location.href = 'index.html';
}

function findRoom(query) {
  const name = query.toLowerCase().trim();
  const s = studentDB.find(x => x.name.toLowerCase() === name);
  return s ? `${s.name} is in ${s.room}.` : `No info for "${query}"`;
}

// db.js - Collegia College Database (Live Tracking Ready)
const DB = {
  teachers: [
    {
      name: "Sanjay Bhan",
      email: "sanjaybhan@gmail.com",
      room: "S-28 Room",
      status: "Out",
      lat: 28.3915278,  // 28°23'29.5"N
      lng: 77.4407778   // 77°26'26.8"E
    },
    {
      name: "Preeti Chaudhary",
      email: "preeti@gmail.com",
      room: "G3 Room",
      status: "Out",
      lat: 28.391227,  // SAME LOCATION
      lng: 77.440120
    },
    {
      name: "Priya Shukla",
      email: "priya@gmail.com",
      room: "S-08",
      status: "Out",
      lat: 28.410852,   // Updated
      lng: 77.341718    // Updated
    }
  ],
  facilities: [
    { name: "Canteen", timing: "10AM-5PM", note: "Hot meals & snacks" },
    { name: "Library", timing: "10AM-5PM", note: "Silence required" }
  ],
  search: function(query) {
    const q = query.toLowerCase();
    const results = [];
    this.teachers.forEach(t => {
      if (t.name.toLowerCase().includes(q) || 
          t.email.toLowerCase().includes(q) || 
          t.room.toLowerCase().includes(q)) {
        results.push({ type: 'teacher', data: t });
      }
    });
    this.facilities.forEach(f => {
      if (f.name.toLowerCase().includes(q)) {
        results.push({ type: 'facility', data: f });
      }
    });
    return results;
  }
};